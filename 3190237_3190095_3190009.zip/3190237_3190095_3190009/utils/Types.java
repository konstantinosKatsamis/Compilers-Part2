package utils;

public enum Types {
    NUMERIC, STRING, NULL, VOID, NAN
}
